#include <Wire.h>
#include "DFRobot_LCD.h"
 const int colorR = 255;
  const int colorG = 0;
  const int colorB = 0;

DFRobot_LCD lcd(16,2);

int bomba=5;
int start=4, paro=3, verde=6,rojo=7, amarillo=8; 
int valor;
void setup() {
  // put your setup code here, to run once:
  lcd.init();
    
    lcd.setRGB(colorR, colorG, colorB);
  pinMode(start, INPUT);
    pinMode(bomba, OUTPUT);
     pinMode(verde, OUTPUT);
      pinMode(rojo, OUTPUT);
        pinMode(paro, INPUT);

}

void loop() {
  digitalWrite(bomba, LOW);
digitalWrite(rojo, HIGH);
lcd.print("ESPERANDO PULSO");
lcd.setCursor (0,1);
lcd.print("PARA EXTRACCION");
delay(50);
lcd.clear();
if((digitalRead(start)==HIGH)){
  
  valor=1;
  }
   
  while(valor==1) {
    if((digitalRead(paro)==HIGH)){
  
  valor=0;
  }
     digitalWrite(rojo, LOW);
      digitalWrite(bomba, HIGH);
      digitalWrite(verde, HIGH);
     delay(50);
     digitalWrite(verde, LOW);
      delay(50);
      lcd.print("LLENANDO TANQUE");
      lcd.setCursor (0,1);
lcd.print("DE AGUAMIEL");
delay(100);
lcd.clear();
     }
     
      
   
    
  // put your main code here, to run repeatedly:

}




/*
  Memsic2125

  Read the Memsic 2125 two-axis accelerometer. Converts the pulses output by the
  2125 into milli-g's (1/1000 of Earth's gravity) and prints them over the
  serial connection to the computer.

  The circuit:
  - X output of accelerometer to digital pin 2
  - Y output of accelerometer to digital pin 3
  - +V of accelerometer to +5V
  - GND of accelerometer to ground

  created 6 Nov 2008
  by David A. Mellis
  modified 30 Aug 2011
  by Tom Igoe

  This example code is in the public domain.

  http://www.arduino.cc/en/Tutorial/Memsic2125
*/

// these constants won't change:
const int xPin = 2;   // X output of the accelerometer
const int yPin = 3;   // Y output of the accelerometer

void setup() {
  // initialize serial communications:
  Serial.begin(9600);
  // initialize the pins connected to the accelerometer as inputs:
  pinMode(xPin, INPUT);
  pinMode(yPin, INPUT);
}

void loop() {
  // variables to read the pulse widths:
  int pulseX, pulseY;
  // variables to contain the resulting accelerations
  int accelerationX, accelerationY;

  // read pulse from x- and y-axes:
  pulseX = pulseIn(xPin, HIGH);
  pulseY = pulseIn(yPin, HIGH);

  // convert the pulse width into acceleration
  // accelerationX and accelerationY are in milli-g's:
  // Earth's gravity is 1000 milli-g's, or 1 g.
  accelerationX = ((pulseX / 10) - 500) * 8;
  accelerationY = ((pulseY / 10) - 500) * 8;

  // print the acceleration
  Serial.print(accelerationX);
  // print a tab character:
  Serial.print("\t");
  Serial.print(accelerationY);
  Serial.println();

  delay(100);
}
