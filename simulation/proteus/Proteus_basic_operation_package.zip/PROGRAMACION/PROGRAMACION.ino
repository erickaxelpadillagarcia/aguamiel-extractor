#include <Wire.h>
#include "DFRobot_LCD.h"
 const int colorR = 255;
  const int colorG = 0;
  const int colorB = 0;

DFRobot_LCD lcd(16,2);

int bomba=5;
int start=4, paro=3, verde=6,rojo=7, amarillo=8; 
int valor;
void setup() {
  // put your setup code here, to run once:
  lcd.init();
    
    lcd.setRGB(colorR, colorG, colorB);
  pinMode(start, INPUT);
    pinMode(bomba, OUTPUT);
     pinMode(verde, OUTPUT);
      pinMode(rojo, OUTPUT);
        pinMode(paro, INPUT);

}

void loop() {
  digitalWrite(bomba, LOW);
digitalWrite(rojo, HIGH);
lcd.print("ESPERANDO PULSO");
lcd.setCursor (0,1);
lcd.print("PARA EXTRACCION");
delay(50);
lcd.clear();
if((digitalRead(start)==HIGH)){
  
  valor=1;
  }
   
  while(valor==1) {
    if((digitalRead(paro)==HIGH)){
  
  valor=0;
  }
     digitalWrite(rojo, LOW);
      digitalWrite(bomba, HIGH);
      digitalWrite(verde, HIGH);
     delay(50);
     digitalWrite(verde, LOW);
      delay(50);
      lcd.print("LLENANDO TANQUE");
      lcd.setCursor (0,1);
lcd.print("DE AGUAMIEL");
delay(100);
lcd.clear();
     }
     
      
   
    
  // put your main code here, to run repeatedly:

}
